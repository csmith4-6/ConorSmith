//Conor Smith, Matthew Gumprecht
//Animation Timer class responsible for determining animation intervals

import javax.swing.Timer;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class AnimationTimer extends Timer {
	private DrawingPanel dp;
	
	public AnimationTimer(DrawingPanel dp) {
		super(10, null);
		this.dp = dp;
		this.addActionListener(new MoveListener());
	}

	private class MoveListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			dp.move();
		}
	}

}