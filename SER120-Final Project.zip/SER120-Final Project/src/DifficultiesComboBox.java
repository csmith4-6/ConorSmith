//Conor Smith, Matthew Gumprecht
//Drop-down box for determining the game's difficulty
//Difficulty includes the enemy movement speed and number of enemies on screen.

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
	
public class DifficultiesComboBox extends JPanel {
	String[] DiffStrings = {"easy", "normal", "difficult"};
	JComboBox Difficulties;

	public DifficultiesComboBox() {
		super(new BorderLayout());

        //Create the combo box.    
		Difficulties = new JComboBox(DiffStrings);
		Difficulties.setFocusable(false);
	    Difficulties.addActionListener(new input());
	    add(Difficulties, BorderLayout.SOUTH);
	}

	public String getitem() {
		String x = String.valueOf(Difficulties.getSelectedItem());
		return x;
	 }

	 private class input implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent e) {
			String x = String.valueOf(Difficulties.getSelectedItem());

				//low speed - 3 enemies
			if (x.equals("easy")) {
			    DrawingPanel.gamespeed(6);
			    DrawingPanel.enemyCount(3);
			    Enemy4.setYLocation(-100);
			    Enemy5.setYLocation(-100);

			    //medium speed - 4 enemies
			} else if (x.equals("normal")) {
				DrawingPanel.gamespeed(8);
				DrawingPanel.enemyCount(4);
				Enemy4.setYLocation(120);
				Enemy5.setYLocation(-100);

				//high speed - 5 enemies
			} else if (x.equals("difficult")) {
				DrawingPanel.gamespeed(10);
				DrawingPanel.enemyCount(5);
				Enemy4.setYLocation(120);
				Enemy5.setYLocation(150);
			}
		}
	 }

}