//Conor Smith, Matthew Gumprecht
//Driver class for the game

class App extends javax.swing.JFrame {
   DrawingPanel _drawPanel;
   public App (String title) {

    super(title);
    this.setSize(500, 500);
    this.setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);
    this.add(new MainPanel());
    
    this.pack();
    this.setVisible(true);
  }

   public static void main (String [ ] args) {
		  run r=new run() {
		  public void runn() {
			  App app=new App("App");
		  }
	  };
		  r.runn();
		 // App app = new App ("Run App");
	  }

	  interface run{
		  void runn();
	  }
	}