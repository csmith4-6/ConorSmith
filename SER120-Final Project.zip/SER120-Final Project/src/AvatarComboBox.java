//Conor Smith, Matthew Gumprecht
//Drop-down box for selecting player avatars

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

	public class AvatarComboBox extends JPanel {
		private DrawingPanel dp;
	     String[] petStrings = {"Plain", "TopHat", "Sunglasses"};
	     JComboBox Avatars;

	    public AvatarComboBox() {
	        super(new BorderLayout());

	        Avatars = new JComboBox(petStrings);
	        Avatars.setFocusable(false);
		    Avatars.addActionListener(new input());
	        add(Avatars, BorderLayout.SOUTH);
	    }

	    private class input implements ActionListener{
			@Override
			public void actionPerformed(ActionEvent e) {
				String x = String.valueOf(Avatars.getSelectedItem());
			    System.out.println(x);
			    if (x.equals("Plain")) {
			    	PlayerAvatar.newAvatar(0);
			    } else if (x.equals("Sunglasses")) {
			    	PlayerAvatar.newAvatar(1);
			    } else if (x.equals("TopHat")) {
			    	PlayerAvatar.newAvatar(2);
			    }
			}
	    }
	}