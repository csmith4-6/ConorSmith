//Conor Smith, Matthew Gumprecht
//Reads in one of three images to display for the player's avatar

import java.awt.Graphics;
import java.awt.Image;
import javax.swing.ImageIcon;

public class PlayerAvatar {
	private static int _xlocation, _ylocation;
	public static int _avatarChoice;
	private ImageIcon _playerAvatar1, _playerAvatar2, _playerAvatar3;
    private Image _image, _image1, _image2, _image3;

    public PlayerAvatar(Image image, int xLocation, int yLocation)	{
    	_xlocation = xLocation;
    	_ylocation = yLocation;
    	_image = image;

    	_playerAvatar1 = new ImageIcon("DefaultCat.png");
    	_image1 = _playerAvatar1.getImage();
    	
    	_playerAvatar2 = new ImageIcon("SunglassesCat.png");
    	_image2 = _playerAvatar2.getImage();
    	
    	_playerAvatar3 = new ImageIcon("TopHatCat3.png");
    	_image3 = _playerAvatar3.getImage();
    	
    }

   public static int newAvatar(int x) {
	   _avatarChoice = x;
	   return _avatarChoice;
   }

   public static int getXLocation() {
		return _xlocation;
   }

   public static int getYLocation() {
	   return _ylocation;
   }

   public static void setXLocation(int newXLocation) {
	   _xlocation = newXLocation;
	   System.out.println("Location on X Axis is:" + _xlocation);
   }

   public static void setYLocation(int newYLocation) {
	   if (newYLocation > 0 && newYLocation < 300) {
		  _ylocation = newYLocation;
		  System.out.println("Location on Y Axis is:" + _ylocation);
	   }  
   }

   public void paint(Graphics g) {
	   if (_avatarChoice == 0) {
		   g.drawImage(_image1, _xlocation, _ylocation, null); 
	   } else if (_avatarChoice == 1) {
		   g.drawImage(_image2, _xlocation, _ylocation, null);
	   } else if (_avatarChoice == 2) {
		   g.drawImage(_image3, _xlocation, _ylocation, null);
	   }
   }

}