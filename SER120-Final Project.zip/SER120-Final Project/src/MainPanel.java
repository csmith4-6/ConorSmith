//Conor Smith, Matthew Gumprecht
//The main panel that holds all GUI elements to include the drawing panel and game buttons

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.ButtonGroup;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;


public class MainPanel extends JPanel {
	private JRadioButton _start, _stop, _exit;
	private static JLabel _infoLabel;
	private static DrawingPanel dp;
	private int _gamestate = 1;
	private static int _scoreValue = 0;
	private static int _scoreGoal = 60;
	private static int _playerHealth = 3;
	SoundsHandler sound, movement;

	public MainPanel() {
		super(new BorderLayout());

		DrawingPanel dp = new DrawingPanel();
		dp.setPreferredSize(new Dimension(700, 300));

		this.addKeyListener(new KeyboardListener());
		this.setFocusable(true);
		//Control Panels
		JPanel avatarControls = new JPanel();
		JPanel gamestateControls =new JPanel(new GridLayout(1,3));
		JPanel enemyControls = new JPanel(new GridLayout(3,1));
		JPanel scorePanel = new JPanel();

		//Score Label
		_infoLabel = new JLabel("Goal: " + _scoreGoal + "  Score: " + _scoreValue + "    Health: " + _playerHealth);

		//Button Groups
		ButtonGroup gcGroup = new ButtonGroup();

		//Avatar Buttons
		avatarControls.add(new AvatarComboBox());
		
		//Game State Buttons
			//Start
		_start = new JRadioButton("Start");
		_start.addActionListener(new ButtonListenerStart());
		_start.setFocusable(false);
			//Stop
		_stop = new JRadioButton("Stop");
		_stop.setSelected(true);
		if (_stop.isSelected()) {
			dp.gamestate(1);
		}
		_stop.addActionListener(new ButtonListenerStop());
		_stop.setFocusable(false);
			//Exit
		_exit = new JRadioButton("Exit");
		_exit.addActionListener(new ButtonListenerExit());
		_exit.setFocusable(false);

		gcGroup.add(_start);
		gcGroup.add(_stop);
		gcGroup.add(_exit);
		gamestateControls.add(_start);
		gamestateControls.add(_stop);
		gamestateControls.add(_exit);
		scorePanel.add(_infoLabel);

		//Enemies Buttons
		enemyControls.add(new CountsComboBox());
		enemyControls.add(new DifficultiesComboBox());

		this.add(dp, BorderLayout.CENTER);
		this.add(scorePanel, BorderLayout.NORTH);
		this.add(avatarControls, BorderLayout.EAST);
		this.add(enemyControls, BorderLayout.WEST);
		this.add(gamestateControls, BorderLayout.SOUTH);
		sound = new SoundsHandler("theme");
		movement = new SoundsHandler("jump");
		}


	//Adds a point when enemy passes
	public static void addScore() {
		_scoreValue += 1;
		_infoLabel.setText("Goal: " + _scoreGoal + "  Score: " + _scoreValue + "    Health: " + _playerHealth);
		if (_scoreValue == _scoreGoal) {
			_infoLabel.setText("You Win!");
			DrawingPanel.gamestate(1);
		}
	}


	//Sets game goal limit
	public static int setGoal(int x) {
		_scoreGoal = x;
		_infoLabel.setText("Goal: " + _scoreGoal + "  Score: " + _scoreValue + "    Health: " + _playerHealth);
		return _scoreGoal;
	}

	//Number of lives
	public static void takeDamage() {
		if (_playerHealth > 0) {
			_playerHealth -= 1;
			_infoLabel.setText("Goal: " + _scoreGoal + "  Score: " + _scoreValue + "    Health: " + _playerHealth);
			if (_playerHealth == 0) {
			gameOver();
			}
		}
	}


	//Game over
	public static void gameOver() {
		_infoLabel.setText("You Lose!");
		DrawingPanel.gamestate(1);
	}


	//Game reset
	public static void resetScore() {
		_scoreValue = 0;
		_playerHealth = 3;
		_infoLabel.setText("Goal: " + _scoreGoal + "  Score: " + _scoreValue + "    Health: " + _playerHealth);
	}


	private class KeyboardListener implements KeyListener {
    	@Override
    	public void keyPressed(KeyEvent e) {
			switch (e.getKeyCode()) {

			case KeyEvent.VK_UP:
				if (_gamestate == 0) {
					if (PlayerAvatar.getYLocation() <= 0) {
						PlayerAvatar.setYLocation(0);
						return;
					}
					PlayerAvatar.setYLocation(PlayerAvatar.getYLocation() - 20);
					System.out.println("Up 50");
					movement.startSound(0);
					return;
				}
			case KeyEvent.VK_DOWN:
				if (_gamestate == 0) {
					if (PlayerAvatar.getYLocation() >= 300) {
						PlayerAvatar.setYLocation(300);
						return;
					}
					PlayerAvatar.setYLocation(PlayerAvatar.getYLocation() + 20);
					System.out.println("Down 50");
					movement.startSound(0);
					return;
				}
			}
			movement.stopSound();
		}
    	//Unimplemented methods
		@Override
		public void keyReleased(KeyEvent arg0) {}
		public void keyTyped(KeyEvent arg0) {}
	}

	//Game State Button Action Performed
	private class ButtonListenerExit implements ActionListener {
    	@Override
		public void actionPerformed(ActionEvent e) {
			System.exit(0);
    	}
    }

	private class ButtonListenerStart implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			dp.gamestate(0);
			_gamestate = 0;
			resetScore();
			sound.startSound(100);
		}
	}

	private class ButtonListenerStop implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			dp.gamestate(1);
			_gamestate = 1;
			sound.stopSound();
		}
	}

}