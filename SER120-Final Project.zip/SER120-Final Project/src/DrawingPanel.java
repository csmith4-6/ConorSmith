//Conor Smith, Matthew Gumprecht
//Drawing panel that will display all moving game elements
//Location for player controls via mouse or arrow keys

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;

public class DrawingPanel extends javax.swing.JPanel {
	private Image _avatarImage, _enemyImage;
	private ArrayList<PlayerAvatar> _avatars;
	private ArrayList<Enemies> _enemies;
	private ArrayList<Enemy2> _enemy2;
	private ArrayList<Enemy3> _enemy3;
	private ArrayList<Enemy4> _enemy4;
	private ArrayList<Enemy5> _enemy5;
	private AnimationTimer _timer;
	private static int _state;
	private static int _speed = 10;
	private static int _mouseStartY;
	private static int _enemyCount = 3;
	private int i = 0;

    public DrawingPanel() {
       super();
       Color backgroundColor = new Color(135, 206, 235);
       this.setBackground(backgroundColor);
       this.setSize(1000, 900);
       this.setPreferredSize(new Dimension(800, 600));

       this.addMouseListener(new mouseClickedListener());
       this.addMouseMotionListener(new mouseMotionListener());

       //Player Avatar1
       _avatars = new ArrayList<PlayerAvatar>();
       _avatars.add(new PlayerAvatar(_avatarImage, 650, 20));
       repaint();

       //Enemies
       	//Enemy 1
       _enemies = new ArrayList<Enemies>();
       _enemies.add(new Enemies(_enemyImage, 30, 20));
       _enemies.add(new Enemies(_enemyImage, 30, 40));
       _enemies.add(new Enemies(_enemyImage, 30, 200));

       	//Enemy2
       _enemy2 = new ArrayList<Enemy2>();
       _enemy2.add(new Enemy2(_enemyImage, 20, 60));

       	//Enemy3
       _enemy3 = new ArrayList<Enemy3>();
       _enemy3.add(new Enemy3(_enemyImage, 10, 80));

       	//Enemy4
       _enemy4 = new ArrayList<Enemy4>();
       _enemy4.add(new Enemy4(_enemyImage, 15, -100));
       
       	//Enemy5
       _enemy5 = new ArrayList<Enemy5>();
       _enemy5.add(new Enemy5(_enemyImage, 5, -100));

       //Timer
       _timer = new AnimationTimer(this);
       _timer.start();
    }

    
    //Set's game state (running or paused)
    public static int gamestate(int x) {
		_state = x;
		return _state;
	}

    
    //Game/Enemy speed
    public static int gamespeed(int x) {
    	_speed = x;
    	return _speed;
    }
    
    
    //Number of visible enemies
    public static int enemyCount(int x)	{
    	_enemyCount = x;
    	return _enemyCount;
    }

    public void move() {
    	if (_state == 0) {
    		Enemies.move(_speed);
    		Enemy2.move(_speed);
    		Enemy3.move(_speed);
    		if (_enemyCount == 4) {
    			Enemy4.move(_speed);
    		}
    		if (_enemyCount == 5) {
    			Enemy4.move(_speed);
    			Enemy5.move(_speed);
    		}
    	} else if (_state == 1) {
    		Enemies.move(0);
    		Enemy2.move(0);
    		Enemy3.move(0);
    		Enemy4.move(0);
    		Enemy5.move(0);
    	}
    }

    //Player Mouse Controls
    private class mouseClickedListener implements MouseListener {
		public void mousePressed(MouseEvent e) {
			_mouseStartY = e.getY();
		}
		//Unimplemented MouseListener Methods
		public void mouseClicked(MouseEvent arg0) {}
		public void mouseEntered(MouseEvent arg0) {}
		public void mouseExited(MouseEvent arg0) {}
		public void mouseReleased(MouseEvent arg0) {}
    }

    private class mouseMotionListener implements MouseMotionListener {
    	@Override
    	public void mouseDragged(MouseEvent e) {
    		PlayerAvatar.setYLocation(e.getY());
    	}

	@Override
	public void mouseMoved(MouseEvent arg0) {}
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        PlayerAvatar f = _avatars.get(_avatars.size() - 1);
        f.paint(g);
        repaint();

        while (i < _enemies.size()) {
        	Enemies e = _enemies.get(i);
        	e.paint(g);
        	System.out.println(i);
        	i++;
        }
        Enemies e = _enemies.get(1);
    	e.paint(g);

    	Enemy2 h = _enemy2.get(0);
    	h.paint(g);
    	
    	Enemy3 j = _enemy3.get(0);
    	j.paint(g);
    	
    	Enemy4 k = _enemy4.get(0);
    	k.paint(g);

    	Enemy5 l = _enemy5.get(0);
    	l.paint(g);

    	repaint();
    }

}