//Conor Smith, Matthew Gumprecht
//Class for game enemies and their parameters

import java.awt.Graphics;
import java.awt.Image;
import javax.swing.ImageIcon;

public class Enemies {
	private static int _xlocation, _ylocation;
	private static MainPanel mp;
	private ImageIcon _enemyAvatar;
    private Image _image;

    public Enemies(Image image, int xLocation, int yLocation)	{
    	_xlocation = xLocation;
    	_ylocation = yLocation;
    	_image = image;
    	_enemyAvatar = new ImageIcon("Vulture.png");
    	_image = _enemyAvatar.getImage();
    }

   public static int getXLocation() {
		return _xlocation;
   }

   public static int getYLocation() {
	   return _ylocation;
   }

   public static void setXLocation(int newXLocation) {
	   _xlocation = newXLocation;
   }

   public static void setYLocation(int newYLocation) {
	   _ylocation = newYLocation;
   }

   //Move enemies and determine their location relative to the player
   public static void move(int dx) {
		_xlocation += dx;
		int random=(int) (Math.random()*301);
		if (_xlocation == PlayerAvatar.getXLocation() && (_ylocation <= PlayerAvatar.getYLocation() + 10 && _ylocation >= PlayerAvatar.getYLocation() - 10)) {
			mp.takeDamage();
		}
		if (_xlocation > 690) {
			MainPanel.addScore();
			_xlocation = _xlocation - _xlocation;
			 setYLocation(random);
		}
	}

   public void paint(Graphics g) {
	   g.drawImage(_image, _xlocation, _ylocation, null);
   }

}