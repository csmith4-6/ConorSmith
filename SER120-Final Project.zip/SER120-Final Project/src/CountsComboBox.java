//Conor Smith, Matthew Gumprecht
//Drop-down box for determining how many points you want to score.

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

	public class CountsComboBox extends JPanel {
	     String[] counts = {"60 Evasions", "90 Evasions", "120 Evasions", "150 Evasions", "180 Evasions"};
	     JComboBox Counts;
	 public CountsComboBox() {
	     super(new BorderLayout());

	     //Create the combo box.
	     Counts = new JComboBox(counts);
	     Counts.setFocusable(false);
	     Counts.addActionListener(new input());
	     add(Counts, BorderLayout.SOUTH);
	     String x = String.valueOf(Counts.getSelectedItem());
	 }

	 private class input implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent e) {
			String x = String.valueOf(Counts.getSelectedItem());

			if (x.equals("60")) {
			    MainPanel.setGoal(60);

			} else if (x.equals("90 Evasions")) {
				MainPanel.setGoal(90);

			} else if (x.equals("120 Evasions")) {
				MainPanel.setGoal(120);

			} else if (x.equals("150 Evasions")) {
				MainPanel.setGoal(150);

			} else if (x.equals("180 Evasions")) {
				MainPanel.setGoal(180);
			}
		}
	 }

}