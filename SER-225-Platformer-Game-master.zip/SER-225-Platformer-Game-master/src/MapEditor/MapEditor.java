package MapEditor;

public class MapEditor {
    public static void main(String[] args) {
        new EditorWindow();
    }
}
